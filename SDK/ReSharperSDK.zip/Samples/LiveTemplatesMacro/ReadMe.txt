﻿Live Templates Macro

This PowerToy shows two Live Template macros - one which returns the current file path, another
that returns the return type of the method the user is in.