﻿using JetBrains.Application.PluginSupport;

//[assembly: AssemblyTitle("ReSharper PSI Plugin")]

[assembly: PluginVendor("JetBrains s.r.o.")]
[assembly: PluginDescription("ReSharper PSI Plugin")]