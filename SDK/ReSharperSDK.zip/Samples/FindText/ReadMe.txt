﻿Find Text

This PowerToy demonstrates how to perform a text search within the code base and present
the results in a tool window. It illustrates the following ReSharper concepts:

 * Action
 * Search

This plug-in demonstrates how one would create a dialog box for querying the search string,
perform the search and present the results in a Find Results window.