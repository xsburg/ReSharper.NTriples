class A
{
  void Foo()
  {
  var s = 1 + 2147483647{caret};
  }
}