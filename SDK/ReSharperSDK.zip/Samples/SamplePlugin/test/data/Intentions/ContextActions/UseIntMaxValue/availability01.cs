class A
{
  void Foo()
  {
    int s = 2147483647{on};
    int h = 12{of};
  }
}