class C
{
  public static void Main()
  {
    (32767 - 1 + 32767.0).ToString();
  }
}