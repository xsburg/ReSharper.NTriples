class A{caret}
{
  void Foo()
  {
    var a = new A();
  }
}

class B : System.Collections.Generic.List<A> {}
