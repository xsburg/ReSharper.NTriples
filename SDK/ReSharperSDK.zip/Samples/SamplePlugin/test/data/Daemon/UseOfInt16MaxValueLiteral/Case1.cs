class C
{
  public static void Main()
  {
    (32767 - 1).ToString();
  }
}