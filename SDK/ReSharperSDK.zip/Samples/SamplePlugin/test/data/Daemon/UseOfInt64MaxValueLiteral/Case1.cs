class C
{
  public static void Main()
  {
    (9223372036854775807L - 1).ToString();
  }
}