﻿namespace JetBrains.ReSharper.PsiPlugin.Resolve
{
  public static class PsiResolveUtil
  {
    public static string ReferenceName(string text)
    {
      return text;
    }
  }
}
