﻿namespace JetBrains.ReSharper.PsiPlugin.Psi.Psi.Tree
{
  partial interface IVariableName
  {
    void SetName(string name);
  }
}
