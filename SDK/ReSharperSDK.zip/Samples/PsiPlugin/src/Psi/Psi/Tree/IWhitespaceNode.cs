﻿using JetBrains.ReSharper.Psi.Tree;

namespace JetBrains.ReSharper.PsiPlugin.Psi.Psi.Tree
{
  public interface IWhitespaceNode : ITokenNode
  {
  }
}
