﻿namespace JetBrains.ReSharper.PsiPlugin.Psi.Psi.Tree.Impl
{
  public static class ChildRole
  {
    public const short LAST = 100;
  }
}
