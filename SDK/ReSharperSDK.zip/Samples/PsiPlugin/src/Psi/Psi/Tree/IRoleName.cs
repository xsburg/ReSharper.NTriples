﻿namespace JetBrains.ReSharper.PsiPlugin.Psi.Psi.Tree
{
  partial interface IRoleName
  {
  }
}
