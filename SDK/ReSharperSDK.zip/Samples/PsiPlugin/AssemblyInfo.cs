﻿using System.Reflection;
using JetBrains.ActionManagement;
using JetBrains.Application.PluginSupport;

[assembly: AssemblyTitle("ReSharper PSI Plugin")]
[assembly: PluginTitle("ReSharper PSI Plugin")]
[assembly: PluginVendor("JetBrains s.r.o.")]
[assembly: PluginDescription("ReSharper PSI Plugin")]
[assembly: ActionsXml("JetBrains.ReSharper.PsiPlugin.resources.actions.xml")]
