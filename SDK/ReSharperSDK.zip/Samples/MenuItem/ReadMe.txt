﻿Menu Item

This PowerToy shows two actions and their corresponding menu items. One of the actions shows the
current line number, the other shows the name of the currently opened solution. This plug-in
illustrates the following ReSharper features:

 * Action

In particular, this action shows how to configure the Actions.xml file in order for the actions
to show up as menu items in the top-level ReSharper|PowerToys menu, ReSharper's Navigate menu,
the Solution, Project and Item explorer menus, as well as the Visual Studio code window command
bar.