﻿Gist

This PowerToy demonstrates how one would send selected code directly into the Gist service
(see http://gist.github.com). It illustrates the following ReSharper features:

 * Action
 * Settings
 * Options Page

The plug-in shows how one would store and edit settings related to GitHub connection as well
as how one would actually take the user-selected data and send it to the service. Note that
special action is needed to insure that web-based operations work correctly in presence
of restrictions such as firewalls.