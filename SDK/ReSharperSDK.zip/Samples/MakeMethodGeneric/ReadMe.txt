﻿Make Method Generic

This PowerToy implements a refactoring which lets the user make a method generic. It illustrates
the following ReSharper features:

 * Action
 * Refactoring

 The plug-in shows how one would go about instrumenting the refactoring, querying for the type
 parameter, as well as handling situations where the refactoring results in a conflict or is
 not supported.