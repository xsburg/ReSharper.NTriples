﻿Options Page

This PowerPoys shows how to create an options page in the ReSharper Options menu.
This plug-in has no functionality apart from demonstrating the options page and the
associated persistence. The ReSharper features illustrated by this plug-in are:

 * Options Page
 * Settings

Of particular interest here is the way in which the settings are defined, as well as
the call which binds them to the UI element.